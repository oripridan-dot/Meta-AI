module.exports = function buildPrompt({ task, basePrompt, learnings = [], perf = {} }) {
  const taskHints = {
    fibonacci: "Use O(n) iterative; handle n=0,1.",
    factorial: "Iterative; n=0→1; avoid recursion depth.",
    isPrime: "Check up to √n; special-case 2; skip evens; consider 6k±1."
  }[task] || "";

  const learn = (Array.isArray(learnings) ? learnings : Array.from(learnings || [])).slice(-3);
  const learnStr = learn.length ? `Apply: ${learn.join(', ')}.` : "";

  const perfMsgs = [];
  if (Number.isFinite(perf.execMs) && perf.execMs > 10) perfMsgs.push("Optimize runtime.");
  if (Number.isFinite(perf.quality) && perf.quality < 60) perfMsgs.push("Prefer clear naming and low cyclomatic complexity.");

  return [
    `Create a JavaScript function named ${task} that solves: ${basePrompt}.`,
    taskHints,
    learnStr,
    perfMsgs.join(' '),
    "Return only the complete function (no prose, no markdown).",
    `Ensure the function is named exactly "${task}" and accepts a single parameter.`
  ].filter(Boolean).join(' ');
};
