// src/core/code-executor.js
const { VM } = require('vm2');

class CodeExecutor {
  constructor() {
    this.timeout = 5000; // 5 second timeout for code execution
    this.maxMemory = 50 * 1024 * 1024; // 50MB memory limit
  }

  async executeCode(code, functionName, testInput) {
    const startTime = process.hrtime.bigint();
    const initialMemory = process.memoryUsage().heapUsed;
    
    console.log(`⚡ Executing ${functionName}(${testInput})`);
    console.log(`🔧 Code to execute:\n${code.substring(0, 150)}...`);
    
    try {
      // Create secure VM environment
      const vm = new VM({ timeout: this.timeout, sandbox: { module: { exports: undefined }, exports: {} } });

      // Wrap the code to make it returnable
      const wrappedCode = this.wrapCode(code, functionName);
      console.log(`📦 Wrapped code:\n${wrappedCode}`);
      
      // Execute the code and get the function
      const func = vm.run(wrappedCode);
      
      if (typeof func !== 'function') {
        throw new Error(`Generated code did not return a function. Got: ${typeof func}`);
      }
      
      // Test the function with provided input
      const executionStart = process.hrtime.bigint();
      const result = func(testInput);
      const executionEnd = process.hrtime.bigint();
      
      const executionTime = Number(executionEnd - executionStart) / 1000000; // Convert to milliseconds
      const finalMemory = process.memoryUsage().heapUsed;
      const memoryUsed = finalMemory - initialMemory;
      
      console.log(`✅ Execution successful: ${functionName}(${testInput}) = ${result}`);
      console.log(`⏱️  Execution time: ${executionTime.toFixed(3)}ms`);
      console.log(`💾 Memory used: ${(memoryUsed / 1024).toFixed(2)}KB`);
      
      return {
        success: true,
        result,
        executionTime,
        memoryUsed: Math.max(0, memoryUsed), // Ensure non-negative
        testInput,
        functionName
      };
      
    } catch (error) {
      console.error(`❌ Execution failed: ${error.message}`);
      
      return {
        success: false,
        error: error.message,
        executionTime: Infinity,
        memoryUsed: Infinity,
        testInput,
        functionName
      };
    }
  }

  wrapCode(code, expectedFunctionName) {
    // Clean the code first
    const cleanCode = code.trim();
    
    // Try different wrapping strategies based on code structure
    
    // Strategy 1: If it's already a complete function declaration
    if (cleanCode.startsWith('function ')) {
      return `${cleanCode}; ${this.extractFunctionName(cleanCode)};`;
    }
    
    // Strategy 2: If it's a const/let function assignment
    if (cleanCode.match(/^(const|let|var)\s+\w+\s*=\s*(function|\(.*\)\s*=>)/)) {
      return `${cleanCode}; ${this.extractVariableName(cleanCode)};`;
    }
    
    // Strategy 3: If it's just the function body, wrap it
    if (!cleanCode.includes('function') && !cleanCode.includes('=>')) {
      return `function ${expectedFunctionName}(n) { ${cleanCode} }; ${expectedFunctionName};`;
    }
    
    // Strategy 4: Arrow function
    if (cleanCode.includes('=>')) {
      const varName = this.extractVariableName(cleanCode) || expectedFunctionName;
      return `${cleanCode}; ${varName};`;
    }
    
    // Default: assume it's a function and try to extract the name
    const functionName = this.extractFunctionName(cleanCode) || expectedFunctionName;
    return `${cleanCode}; ${functionName};`;
  }

  extractFunctionName(code) {
    // Extract function name from function declaration
    const functionMatch = code.match(/function\s+(\w+)/);
    if (functionMatch) return functionMatch[1];
    
    return null;
  }

  extractVariableName(code) {
    // Extract variable name from const/let/var assignment
    const varMatch = code.match(/^(const|let|var)\s+(\w+)/);
    if (varMatch) return varMatch[2];
    
    return null;
  }

  // Enhanced complexity analysis specific to algorithm patterns
  analyzeComplexity(code, task) {
    const complexityPatterns = {
      fibonacci: {
        'O(2^n) - Naive Recursive': {
          pattern: /fibonacci\s*\([^)]*-\s*1[^)]*\)\s*[+\-*\/]\s*fibonacci\s*\([^)]*-\s*2/,
          score: 30
        },
        'O(n) - Memoized': {
          pattern: /(?:memo|cache|Map|{|}.*fibonacci)|(?:dp|table)/i,
          score: 85
        },
        'O(n) - Iterative': {
          pattern: /for\s*\([^}]*\)\s*{[^}]*(?!fibonacci\s*\()[^}]*}/,
          score: 90
        },
        'O(1) - Matrix Power': {
          pattern: /matrix|Math\.pow|golden.*ratio/i,
          score: 100
        }
      },
      prime: {
        'O(n) - Naive': {
          pattern: /for\s*\([^}]*i\s*<\s*n[^}]*\)/,
          score: 40
        },
        'O(√n) - Square Root': {
          pattern: /i\s*\*\s*i\s*<=?\s*n|Math\.sqrt|i\s*<=?\s*Math\.sqrt/,
          score: 90
        },
        'O(√n) - 6k±1 Optimization': {
          pattern: /i\s*\+=?\s*[46]|6.*k/,
          score: 95
        }
      },
      factorial: {
        'O(n) - Recursive': {
          pattern: /factorial\s*\([^)]*-\s*1/,
          score: 60
        },
        'O(n) - Iterative': {
          pattern: /for\s*\([^}]*\)\s*{[^}]*\*=[^}]*}/,
          score: 90
        }
      }
    };
    
    const patterns = complexityPatterns[task] || {};
    
    for (const [complexity, { pattern, score }] of Object.entries(patterns)) {
      if (pattern.test(code)) {
        return { complexity, score };
      }
    }
    
    return { complexity: 'Unknown', score: 50 };
  }

  // Comprehensive code quality analysis
  analyzeCodeQuality(code) {
    let qualityScore = 0;
    const metrics = {};
    
    // Readability metrics
    const hasComments = /\/\*[\s\S]*\*\/|\/\//.test(code);
    const hasGoodNaming = /[a-zA-Z][a-zA-Z0-9]{2,}/.test(code);
    const hasProperIndentation = /^\s{2,}/m.test(code);
    const usesModernJS = /((const|let)\s+|=>)/.test(code);
    
    metrics.readability = {
      hasComments,
      hasGoodNaming, 
      hasProperIndentation,
      usesModernJS,
      score: (hasComments ? 25 : 0) + (hasGoodNaming ? 25 : 0) + 
             (hasProperIndentation ? 25 : 0) + (usesModernJS ? 25 : 0)
    };
    
    // Code structure metrics
    const lineCount = code.split('\n').length;
    const cyclomaticComplexity = this.calculateCyclomaticComplexity(code);
    
    metrics.structure = {
      lineCount,
      cyclomaticComplexity,
      conciseness: Math.max(0, 100 - lineCount * 2),
      simplicity: Math.max(0, 100 - cyclomaticComplexity * 10)
    };
    
    // Calculate overall quality score
    qualityScore = (
      metrics.readability.score * 0.4 +
      metrics.structure.conciseness * 0.3 +
      metrics.structure.simplicity * 0.3
    );
    
    return {
      overallScore: Math.round(qualityScore),
      ...metrics
    };
  }

  calculateCyclomaticComplexity(code) {
    // Count complexity indicators
    const indicators = code.match(/if|else|for|while|case|catch|&&|\|\||switch|\?/g) || [];
    return indicators.length + 1; // Base complexity is 1
  }

  // Generate comprehensive performance report
  generatePerformanceReport(code, executionResult, task) {
    const complexityAnalysis = this.analyzeComplexity(code, task);
    const qualityAnalysis = this.analyzeCodeQuality(code);
    
    // Calculate composite performance score
    let performanceScore = 0;
    
    if (executionResult.success) {
      // Time performance (logarithmic scale to handle wide time ranges)
      const timeScore = Math.max(0, 100 - Math.log10(Math.max(0.001, executionResult.executionTime)) * 25);
      
      // Memory efficiency
      const memoryScore = Math.max(0, 100 - executionResult.memoryUsed / 1000);
      
      // Algorithmic sophistication
      const algorithmScore = complexityAnalysis.score;
      
      performanceScore = (
        timeScore * 0.4 +
        memoryScore * 0.2 +
        algorithmScore * 0.25 +
        qualityAnalysis.overallScore * 0.15
      );
    }
    
    return {
      overallScore: Math.round(performanceScore),
      execution: {
        success: executionResult.success,
        result: executionResult.result,
        executionTime: executionResult.executionTime,
        memoryUsed: executionResult.memoryUsed,
        error: executionResult.error
      },
      algorithm: complexityAnalysis,
      quality: qualityAnalysis,
      timestamp: new Date()
    };
  }
}

module.exports = CodeExecutor;