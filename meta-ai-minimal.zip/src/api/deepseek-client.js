// src/api/deepseek-client.js
const axios = require('axios');

class DeepSeekClient {
  constructor(apiKey) {
    this.apiKey = apiKey;
    this.baseURL = 'https://api.deepseek.com/v1/chat/completions';
    this.model = 'deepseek-coder';
    
    // Request tracking for debugging
    this.requestCount = 0;
    this.tokenUsage = 0;
  }

  async generateCode(prompt, task = 'unknown') {
    this.requestCount++;
    const requestStart = Date.now();
    
    console.log(`🤖 [Request #${this.requestCount}] Generating code for: ${task}`);
    console.log(`📝 Prompt: ${prompt.substring(0, 100)}...`);
    
    try {
      const response = await axios.post(this.baseURL, {
        model: this.model,
        messages: [
          {
            role: "system",
            content: "You are DeepSeek Coder, an expert programming AI. Generate clean, efficient, optimized code. Return ONLY the requested function code without explanations, comments about the code, or markdown formatting unless specifically requested."
          },
          {
            role: "user", 
            content: prompt
          }
        ],
        max_tokens: 1000,
        temperature: 0.1, // Low temperature for consistent, deterministic code
        top_p: 0.95,
        stream: false
      }, {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.apiKey}`
        },
        timeout: 30000 // 30 second timeout
      });
      
      const responseTime = Date.now() - requestStart;
      const generatedCode = this.extractCode(response.data.choices[0].message.content);
      
      // Track usage
      if (response.data.usage) {
        this.tokenUsage += response.data.usage.total_tokens;
        console.log(`📊 Tokens used: ${response.data.usage.total_tokens} | Total: ${this.tokenUsage}`);
      }
      
      console.log(`✅ Code generated in ${responseTime}ms`);
      console.log(`🔧 Generated:\n${generatedCode.substring(0, 200)}...`);
      
      return {
        code: generatedCode,
        requestTime: responseTime,
        tokensUsed: response.data.usage?.total_tokens || 0
      };
      
    } catch (error) {
      console.error(`❌ DeepSeek API Error:`, {
        status: error.response?.status,
        message: error.response?.data?.error?.message || error.message,
        prompt: prompt.substring(0, 50) + '...'
      });
      
      throw new Error(`DeepSeek API Error: ${error.response?.data?.error?.message || error.message}`);
    }
  }

  extractCode(response) {
    // Clean up the response and extract just the code
    let code = response.trim();
    
    // Remove markdown code blocks
    const codeBlockPatterns = [
      /```(?:javascript|js|JavaScript)\n([\s\S]*?)\n```/g,
      /```\n([\s\S]*?)\n```/g,
      /`([^`\n]+)`/g
    ];
    
    for (const pattern of codeBlockPatterns) {
      const match = code.match(pattern);
      if (match) {
        code = match[0].replace(/```(?:javascript|js|JavaScript)?\n?/g, '').replace(/\n?```/g, '').trim();
        break;
      }
    }
    
    // Remove explanatory text before/after function
    const functionPatterns = [
      /function\s+\w+[\s\S]*?^}/m,
      /const\s+\w+\s*=\s*(?:\([^)]*\)\s*=>[\s\S]*?;|\w+[\s\S]*?;)/m,
      /\w+\s*=\s*function[\s\S]*?^}/m
    ];
    
    for (const pattern of functionPatterns) {
      const match = code.match(pattern);
      if (match) {
        return match[0].trim();
      }
    }
    
    // If no clear function pattern, return cleaned response
    return code
      .split('\n')
      .filter(line => !line.startsWith('//') || line.includes('function') || line.includes('=>'))
      .join('\n')
      .trim();
  }

  // Enhanced prompt optimization based on DeepSeek Coder strengths
  optimizePrompt(basePrompt, task, learnings = [], performanceHistory = []) {
    let prompt = `Create a ${task} function in JavaScript. ${basePrompt}`;
    
    // Task-specific optimizations for better DeepSeek responses
    const taskSpecifics = {
      fibonacci: "Consider time complexity: O(2^n) recursive is slow, O(n) iterative or memoized is better.",
      prime: "For prime checking, optimize with square root limit and handle edge cases (2, 3, even numbers).",
      factorial: "Use iterative approach to avoid stack overflow for large numbers.",
      sorting: "Choose efficient sorting algorithm based on input characteristics.",
      palindrome: "Consider string manipulation efficiency and edge cases.",
      search: "Implement binary search if input is sorted, otherwise linear search."
    };
    
    if (taskSpecifics[task]) {
      prompt += ` ${taskSpecifics[task]}`;
    }
    
    // Add learnings from previous successful iterations
    if (learnings.length > 0) {
      prompt += ` Apply these proven techniques: ${learnings.slice(-3).join(', ')}.`;
    }
    
    // Performance-based guidance
    if (performanceHistory.length > 0) {
      const lastPerformance = performanceHistory[performanceHistory.length - 1];
      if (lastPerformance.executionTime > 10) {
        prompt += " Prioritize algorithmic efficiency and minimize time complexity.";
      }
      if (lastPerformance.overallScore < 60) {
        prompt += " Focus on clean, readable code with proper variable names.";
      }
    }
    
    prompt += " Return only the complete function implementation, no explanations.";
    
    return prompt;
  }

  getUsageStats() {
    return {
      totalRequests: this.requestCount,
      totalTokens: this.tokenUsage,
      estimatedCost: 0, // DeepSeek free tier
      remainingFreeTokens: Math.max(0, 2000000 - this.tokenUsage) // 2M daily limit
    };
  }
}

module.exports = DeepSeekClient;