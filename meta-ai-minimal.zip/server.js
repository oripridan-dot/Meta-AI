require('dotenv').config();
const express = require('express');
const { MultiAgentSystem } = (function(){try{return require('./integration_utils')}catch(e){try{return require('./src/integration_utils')}catch(_){return {}}}})();
const app = express();
const port = process.env.PORT || 3000;

app.get('/health', async (_req, res) => {
  try {
    const status = await (MultiAgentSystem?.testSystemHealth?.() || { success:true, message:'ok' });
    res.status(status.success ? 200 : 500).json(status);
  } catch (e) {
    res.status(500).json({ success:false, error: e.message });
  }
});

app.listen(port, () => console.log('✅ Health server listening on', port));
