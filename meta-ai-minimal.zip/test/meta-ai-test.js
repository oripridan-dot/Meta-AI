// test/meta-ai-test.js
require('dotenv').config();
const MetaAI = require('../src/core/meta-ai');

async function runMetaAIEvolutionTest() {
  console.log('🚀 META-AI EVOLUTION TEST STARTING');
  console.log('='.repeat(60));
  
  // Check for API key
  if (!process.env.DEEPSEEK_API_KEY) {
    console.error('❌ DEEPSEEK_API_KEY not found in environment');
    console.log('💡 Please set your API key: export DEEPSEEK_API_KEY=your_key_here');
    process.exit(1);
  }
  
  console.log('✅ DeepSeek API key found');
  console.log('📡 Initializing Meta-AI system...\n');
  
  // Initialize Meta-AI
  const metaAI = new MetaAI(process.env.DEEPSEEK_API_KEY);
  
  // Test cases for different algorithmic challenges
  const testCases = {
    fibonacci: {
      prompt: "Create a function that calculates the nth Fibonacci number efficiently",
      testInput: 25,
      expectedEvolution: "O(2^n) recursive → O(n) iterative/memoized",
      description: "Tests algorithmic optimization from exponential to linear complexity"
    },
    prime: {
      prompt: "Create a function that checks if a number is prime",
      testInput: 1009, // Large prime number for performance testing
      expectedEvolution: "O(n) trial division → O(√n) optimized",
      description: "Tests mathematical optimization techniques"
    },
    factorial: {
      prompt: "Create a function that calculates the factorial of a number",
      testInput: 12,
      expectedEvolution: "Recursive → Iterative for stack safety",
      description: "Tests stack overflow prevention and iterative optimization"
    }
  };
  
  const results = {};
  
  // Run evolution tests for each algorithm
  for (const [taskName, config] of Object.entries(testCases)) {
    console.log('\n' + '🎯'.repeat(30));
    console.log(`TESTING: ${taskName.toUpperCase()}`);
    console.log(`Description: ${config.description}`);
    console.log(`Expected Evolution: ${config.expectedEvolution}`);
    console.log('🎯'.repeat(30) + '\n');
    
    try {
      // Run 5 evolution cycles
      const taskResult = await metaAI.runMultipleEvolutions(
        taskName,
        config.prompt,
        config.testInput,
        5, // 5 generations
        { verbose: true }
      );
      
      results[taskName] = {
        success: true,
        ...taskResult,
        config
      };
      
      console.log(`✅ ${taskName.toUpperCase()} evolution completed successfully`);
      
    } catch (error) {
      console.error(`❌ ${taskName.toUpperCase()} evolution failed:`, error.message);
      results[taskName] = {
        success: false,
        error: error.message,
        config
      };
    }
    
    // Reset for next test
    metaAI.reset();
    
    // Pause between different algorithm tests
    if (Object.keys(results).length < Object.keys(testCases).length) {
      console.log('\n⏳ Pausing 5 seconds between algorithm tests...\n');
      await new Promise(resolve => setTimeout(resolve, 5000));
    }
  }
  
  // Generate comprehensive test report
  generateTestReport(results);
}

function generateTestReport(results) {
  console.log('\n' + '='.repeat(80));
  console.log('🎯 META-AI EVOLUTION TEST REPORT');
  console.log('='.repeat(80));
  
  let totalSuccesses = 0;
  let totalFailures = 0;
  let totalApiUsage = 0;
  let significantImprovements = 0;
  
  for (const [taskName, result] of Object.entries(results)) {
    console.log(`\n📊 ${taskName.toUpperCase()} RESULTS:`);
    
    if (result.success) {
      totalSuccesses++;
      const summary = result.summary;
      
      console.log(`   ✅ Status: SUCCESS`);
      console.log(`   📈 Score Improvement: ${summary.improvement.score}%`);
      console.log(`   ⚡ Performance Gain: ${summary.improvement.performance}x faster`);
      console.log(`   🧠 Algorithm Evolution: ${summary.improvement.algorithm}`);
      console.log(`   🎓 Learnings: ${summary.learnings.length} acquired`);
      console.log(`   🔢 API Usage: ${summary.apiUsage.totalTokens} tokens`);
      console.log(`   ⏱️  Duration: ${summary.sessionDuration}s`);
      
      totalApiUsage += summary.apiUsage.totalTokens;
      
      if (summary.improvement.score > 20) {
        significantImprovements++;
        console.log(`   🏆 SIGNIFICANT IMPROVEMENT ACHIEVED!`);
      }
      
      // Show progression
      console.log(`   📈 Progression: ${summary.progression.map(p => `G${p.id}:${p.score}%`).join(' → ')}`);
      
    } else {
      totalFailures++;
      console.log(`   ❌ Status: FAILED`);
      console.log(`   💥 Error: ${result.error}`);
    }
  }
  
  // Overall test summary
  console.log('\n' + '='.repeat(80));
  console.log('📋 OVERALL TEST SUMMARY');
  console.log('='.repeat(80));
  console.log(`🎯 Total Tests: ${Object.keys(results).length}`);
  console.log(`✅ Successes: ${totalSuccesses}`);
  console.log(`❌ Failures: ${totalFailures}`);
  console.log(`🏆 Significant Improvements: ${significantImprovements}`);
  console.log(`🔢 Total API Usage: ${totalApiUsage} tokens`);
  console.log(`💰 Estimated Cost: $0 (DeepSeek free tier)`);
  console.log(`📊 Success Rate: ${((totalSuccesses / Object.keys(results).length) * 100).toFixed(1)}%`);
  
  // Key learnings across all tests
  const allLearnings = new Set();
  Object.values(results).forEach(result => {
    if (result.success && result.summary.learnings) {
      result.summary.learnings.forEach(learning => allLearnings.add(learning));
    }
  });
  
  if (allLearnings.size > 0) {
    console.log('\n🎓 KEY LEARNINGS DISCOVERED:');
    Array.from(allLearnings).forEach(learning => {
      console.log(`   • ${learning}`);
    });
  }
  
  // Next steps recommendation
  console.log('\n🚀 NEXT STEPS:');
  if (totalSuccesses > 0) {
    console.log('   ✅ Meta-AI concept validated with real improvements');
    console.log('   📈 Ready for domain expansion (architecture, UX, etc.)');
    console.log('   🏗️  Begin integration with actual project development');
    console.log('   📊 Consider adding more sophisticated learning algorithms');
  } else {
    console.log('   🔧 Debug API integration and error handling');
    console.log('   📝 Review prompt engineering strategies');
    console.log('   🔄 Test with simpler algorithms first');
  }
  
  console.log('\n' + '='.repeat(80));
  console.log('🎉 META-AI EVOLUTION TEST COMPLETE');
  console.log('='.repeat(80));
}

// Error handling for the test
process.on('unhandledRejection', (reason, promise) => {
  console.error('❌ Unhandled Rejection at:', promise, 'reason:', reason);
  process.exit(1);
});

process.on('uncaughtException', (error) => {
  console.error('❌ Uncaught Exception:', error.message);
  process.exit(1);
});

// Run the test
runMetaAIEvolutionTest().catch(error => {
  console.error('❌ Test execution failed:', error.message);
  process.exit(1);
});